//https://leetcode.com/problems/binary-tree-inorder-traversal/

int s;
void helper(struct TreeNode* t,int* arr){
    if(t==NULL) return;
    if(t->left!=NULL) helper(t->left,arr);
    arr[s]=t->val;
    s+=1;
    if(t->right!=NULL) helper(t->right,arr);
}

int* inorderTraversal(struct TreeNode* root, int* returnSize){
    int* r=(int*)malloc(sizeof(int)*(100));
    s=0;
    helper(root,r);
    *returnSize=s;
    return r;
}
