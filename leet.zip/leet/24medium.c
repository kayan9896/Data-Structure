//https://leetcode.com/problems/swap-nodes-in-pairs/

struct ListNode* swapPairs(struct ListNode* head){
    if(head==NULL) return NULL;
    if(head->next==NULL) return head;
    struct ListNode* h2=head->next;
    struct ListNode* tmp=head->next->next;
    head->next->next=head;
    head->next=swapPairs(tmp);
    return h2;
}


