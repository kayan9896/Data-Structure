//https://leetcode.com/problems/sort-list/

struct ListNode* merge(struct ListNode* a, struct ListNode* b){
    struct ListNode* r=(struct ListNode*)malloc(sizeof(struct ListNode));
    struct ListNode* h=r;
    while(a!=NULL&b!=NULL){
        if(a->val<=b->val){
            r->next=a;
            r=r->next;
            a=a->next;
        } 
        else{
            r->next=b;
            r=r->next;
            b=b->next;
        }
        
    }
    if(a!=NULL){
        r->next=a;
        
    }
    if(b!=NULL){
        r->next=b;
        
    }
    return h->next;
}
struct ListNode* sortList(struct ListNode* head){
    if(head==NULL) return NULL;
    if(head->next==NULL) return head;
    struct ListNode* s=head;
    struct ListNode* f=head;
    struct ListNode* mid;
    while(f!=NULL){
        f=f->next;
        if(f!=NULL){
            mid=s;
            s=s->next;
            f=f->next;
        }
    }
    mid->next=NULL;
    struct ListNode* a=sortList(head);
    struct ListNode* b=sortList(s);
    return merge(a,b);
}
