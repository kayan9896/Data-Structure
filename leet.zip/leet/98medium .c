//https://leetcode.com/problems/validate-binary-search-tree/

int help(struct TreeNode* t, double a, double b){
    int r1=1;
    int r2=1;
    if(t==NULL) return 1;
    if(t->val<a||t->val>b||t->val==a||t->val==b){
        return 0;
    }
    r1=help(t->left,a,t->val);
    r2=help(t->right,t->val,b);
    return r1*r2;
}

bool isValidBST(struct TreeNode* root){
    return help(root,-9999999999,9999999999);
}
