//https://leetcode.com/problems/add-two-numbers/submissions/

struct ListNode* addTwoNumbers(struct ListNode* l1, struct ListNode* l2){
    struct ListNode* r=(struct ListNode*)malloc(sizeof(struct ListNode));
    struct ListNode* h=r;
    int c=0;
    while(l1!=NULL&l2!=NULL){
        r->next=(struct ListNode*)malloc(sizeof(struct ListNode));
        r=r->next;
        int a=l1->val;
        int b=l2->val;
        r->val=(a+b+c)%10;
        if(a+b+c>=10) c=1;
        else c=0;
        l1=l1->next;
        l2=l2->next;
        
    }
    while(l2!=NULL){
        r->next=(struct ListNode*)malloc(sizeof(struct ListNode));
        r=r->next;
        int b=l2->val;
        r->val=(b+c)%10;
        if(b+c>=10) c=1;
        else c=0;
        l2=l2->next;
        
    }
    while(l1!=NULL){
        r->next=(struct ListNode*)malloc(sizeof(struct ListNode));
        r=r->next;
        int a=l1->val;
        r->val=(a+c)%10;
        if(a+c>=10) c=1;
        else c=0;
        l1=l1->next;
        
    }
    if(c==1){
        r->next=(struct ListNode*)malloc(sizeof(struct ListNode));
        r->next->val=1;
        r->next->next=NULL;
    }else{r->next=NULL;}
    return h->next;
}

