//https://leetcode.com/problems/median-of-two-sorted-arrays/submissions/

int max(int a, int b){
    if(a>=b) return a;
    else return b;
}
int min(int a, int b){
    if(a<=b) return a;
    else return b;
}
double findMedianSortedArrays(int* nums1, int nums1Size, int* nums2, int nums2Size){
    if(nums1Size>nums2Size) return findMedianSortedArrays(nums2, nums2Size, nums1, nums1Size);
    
    int size=nums1Size+nums2Size;
    int mid=(size-1)/2;
    if(nums1Size==0){
        if(size%2==1) return nums2[mid];
        if(size%2==0) return (nums2[mid]+nums2[mid+1])/(double)2;
    }
    int l=0;
    int r=nums1Size;
    
    while(1){
        int mid1=(l+r)/2;
        int mid2=(size+1)/2-mid1;
        int maxInLeft, minInRight;
        if(mid1>=nums1Size) minInRight=nums2[mid2];            
        else if(mid2>=nums2Size) minInRight=nums1[mid1];  
        else minInRight=min(nums1[mid1],nums2[mid2]);
        if(mid1<=0) maxInLeft=nums2[mid2-1];  
        else if(mid2<=0) maxInLeft=nums1[mid1-1];
        else maxInLeft=max(nums1[mid1-1],nums2[mid2-1]);//   
        if(maxInLeft<=minInRight) {
            if(size%2==1) return maxInLeft;
            if(size%2==0) return (minInRight+maxInLeft)/(double)2;
        }
        else{
            if(mid1>0){
                if(maxInLeft==nums1[mid1-1]){
                    r=mid1-1;
                }else{
                    l=mid1+1;
                }
            }
            else l=mid1+1;
        }
    }
    return 0;
}
