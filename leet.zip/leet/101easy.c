//https://leetcode.com/problems/same-tree/

bool isSameTree(struct TreeNode* p, struct TreeNode* q){
    int r1=1;
    int r2=1;
    if(p==NULL&q==NULL) return 1;
    if((p==NULL&q!=NULL)||(p!=NULL&q==NULL)) return 0;
    if(p->val!=q->val) return 0;
    r1=isSameTree(p->left,q->left);
    r2=isSameTree(p->right,q->right);
    return r1*r2;
}
