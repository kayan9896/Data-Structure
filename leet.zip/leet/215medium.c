//https://leetcode.com/problems/kth-largest-element-in-an-array/

int* merge(int* n1, int* n2, int size1, int size2){
    int i=0;
    int j=0;
    int* s=(int*)malloc(sizeof(int)*(size1+size2));
    while(i<size1&j<size2){
        if(n1[i]<=n2[j]){
            s[i+j]=n1[i];
            i++;
        }else{
            s[i+j]=n2[j];
            j++;
        }
    }
    while(i<size1){
        s[i+j]=n1[i];
        i++;
    }
    while(j<size2){
        s[i+j]=n2[j];
        j++;
    }
    return s;
}
int* mergeSort(int* arr, int a, int b){
    int l=a;
    int r=b;
    int m=(l+r-1)/2;
    if(l==r) {
        int* arr2=(int*)malloc(sizeof(int));
        arr2[0]=arr[l];
        return arr2;
    }
    int* n1=mergeSort(arr,l,m);
    int* n2=mergeSort(arr,m+1,r);
    return merge(n1,n2,m-l+1,r-m);
}
int findKthLargest(int* nums, int numsSize, int k){
    int* nums2=mergeSort(nums,0,numsSize-1);
    return nums2[numsSize-k];
}
