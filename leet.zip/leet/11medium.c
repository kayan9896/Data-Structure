//https://leetcode.com/problems/container-with-most-water/

int min(int a, int b){
    if(a>=b) return b;
    else return a;
}

int maxArea(int* height, int heightSize){
    int i=0;
    int j=heightSize-1;
    int s=0;
    while(i!=j){
        int h=min(height[i],height[j]);
        int w=j-i;
        if(s<h*w) s=h*w;
        if(height[i]>=height[j]) j-=1;
        else i+=1;
    }
    
    return s;
}
